use database PRJ3;
use schema restaurants;

--UDFs allow custom transformations on data.
---Creating a UDF to Classify Ratings
CREATE OR REPLACE FUNCTION classify_rating(rating VARCHAR)
RETURNS STRING
LANGUAGE SQL
AS
$$
CASE
    WHEN rating >= 4 THEN 'Excellent'
    WHEN rating >= 3 THEN 'Good'
    WHEN rating >= 2 THEN 'Average'
    ELSE 'Poor'
END
$$;

-----
CREATE OR REPLACE FUNCTION classify_based_on_cost(cost NUMBER)
RETURNS STRING
LANGUAGE SQL
AS
$$
select CASE
    WHEN cost <= 200 THEN 'Restaurant is cheap'
    WHEN cost > 200 AND cost <= 1300 THEN 'Restaurant is affordable'
    WHEN cost > 1300 AND cost <= 1500 THEN 'Restaurant is Costly and expensive'
    ELSE 'Luxury Restaurant'
END
$$;

--Using the UDF in Queries
SELECT
    restaurant_name,
    rating,
    classify_rating(rating) AS rating_category
FROM restaurant_reviews_table;

SELECT
    restaurant_name,
    cuisine, timings,
    cost,
   classify_based_on_cost(cost) AS Cost_effecient
FROM restaurant_metadata_details where restaurant_name = 'Flechazo';

select * from restaurant_reviews_table limit 10;
select * from restaurant_metadata_details limit 10;
select distinct(cost) as cost from restaurant_metadata_details;
