use database PRJ3;
use schema restaurants;

--Zero Copy Clone allows you to create an instant duplicate without extra storage costs.
---Creating a Clone
CREATE OR REPLACE TABLE restaurant_metadata_details_clone CLONE restaurant_metadata_details;
CREATE OR REPLACE TABLE restaurant_reviews_clone CLONE restaurant_reviews_table;

select * from restaurant_metadata_details;
select * from restaurant_reviews_table;

---Creating Views
----A view in Snowflake is a virtual table that allows users to store complex queries and access them like a table. Views do not store data physically; they dynamically retrieve the latest data when queried.

CREATE OR REPLACE VIEW restaurant_info_view AS
SELECT 
    d.restaurant_id, 
    d.restaurant_name, 
    d.cost, 
    d.cuisine, 
    r.rating, 
    r.comments
FROM restaurant_metadata_details d
LEFT JOIN restaurant_reviews_table r ON d.restaurant_name = r.restaurant_name;

select count(restaurant_id), restaurant_name from PRJ3.RESTAURANTS.RESTAURANT_INFO_VIEW group by restaurant_name;

