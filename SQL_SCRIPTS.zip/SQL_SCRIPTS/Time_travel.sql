use database PRJ3;
use schema restaurants;


---Time travel in snowflake 
----Time Travel allows you to restore tables to a previous state.

--Simulate Deletion
select distinct(restaurant_name) from restaurant_metadata_details;
DELETE FROM restaurant_metadata_details WHERE restaurant_name = 'Paradise';

----Restore the Deleted Data (Using Time Travel)
---(Recovers the state from 5 minutes ago)
CREATE OR REPLACE TABLE restaurant_details_recovered AS 
SELECT * FROM restaurant_metadata_details AT (OFFSET => -60*5);