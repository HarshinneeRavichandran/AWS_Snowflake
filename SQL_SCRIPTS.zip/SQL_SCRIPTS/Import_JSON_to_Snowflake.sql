use  database PRJ3;
create schema Restaurants;


---Create a Table for Staging JSON Data
CREATE OR REPLACE TABLE restaurant_metadata (
    raw_data VARIANT
);

CREATE OR REPLACE TABLE restaurant_reviews (
    raw_data VARIANT
);


---- Load JSON Data into Snowflake
--Create an internal Snowflake stage to store the JSON files:
--upload the JSON manually using UI into the respective stages
CREATE OR REPLACE STAGE json_stage;

--Copy the JSON files from stage to Table
CREATE or replace FILE FORMAT JSON_FILE_FORMAT
TYPE = 'JSON';

COPY INTO restaurant_metadata 
FROM @json_stage 
FILE_FORMAT = (FORMAT_NAME = 'JSON_FILE_FORMAT')
FILES = ('Restaurant names and Metadata.json');  

COPY INTO restaurant_reviews
FROM @json_stage 
FILE_FORMAT = (FORMAT_NAME = 'JSON_FILE_FORMAT')
FILES = ('Restaurant reviews.json');

select * from restaurant_reviews;
select * from restaurant_metadata;














 