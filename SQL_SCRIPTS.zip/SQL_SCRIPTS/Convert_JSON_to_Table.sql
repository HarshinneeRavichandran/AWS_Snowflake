----Flatten the JSON Data
use database PRJ3;
use schema restaurants;

---Extracting data from JSON
select * from restaurant_metadata;
CREATE OR REPLACE TABLE restaurant_metadata_details (
    restaurant_id NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    restaurant_name STRING,
    Cost STRING,
    Cuisine STRING,
    Timings VARCHAR
);

SELECT REPLACE(cost, ',', '') AS cost
FROM restaurant_metadata_details;

INSERT OVERWRITE INTO RESTAURANT_METADATA_DETAILS
(restaurant_name ,
    Cost ,
    Cuisine ,
    Timings )
SELECT
    --restaurant.value:"restaurant_id"::NUMBER,
    restaurant.value:"Name"::STRING AS Restaurant_name,
    --restaurant.value:"Cost"::STRING AS Cost,
    TO_NUMBER(REPLACE(restaurant.value:"Cost", ',', '')) AS Cost_Int,
    restaurant.value:"Cuisines"::STRING AS Cuisine,
    restaurant.value:"Timings"::VARCHAR AS Timings
FROM restaurant_metadata,
LATERAL FLATTEN(input => raw_data) AS restaurant;


select distinct(cost) from restaurant_metadata_details;


select * from restaurant_metadata_details;


--------------------------------------------------------------------
select * from restaurant_reviews;
CREATE OR REPLACE TABLE restaurant_reviews_table (
 restaurant_name STRING,
 rating VARCHAR,
 comments VARCHAR,
 DATE_TIME STRING,
 REVIEWER VARCHAR );

INSERT OVERWRITE INTO restaurant_reviews_table (
restaurant_name ,
 rating ,
 comments ,
 DATE_TIME ,
 REVIEWER 
) 
SELECT 
    restaurant.value:"Restaurant"::STRING AS restaurant_name,
    restaurant.value:"Rating"::VARCHAR AS rating,
    restaurant.value:"Review"::VARCHAR AS comments,
    restaurant.value:"Time"::STRING AS DATE_TIME,
    restaurant.value:"Reviewer"::VARCHAR AS REVIEWER,
FROM restaurant_reviews,
LATERAL FLATTEN(input => raw_data) AS restaurant;

select * from restaurant_reviews_table;
select * from restaurant_metadata_details;






